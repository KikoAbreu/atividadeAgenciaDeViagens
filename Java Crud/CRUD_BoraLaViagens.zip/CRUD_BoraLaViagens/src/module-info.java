/**
 * 
 */
/**
 * 
 */
module CRUD_BoraLaViagens {
	requires java.sql;
}